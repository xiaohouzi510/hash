#!/bin/env python
# -*- coding: utf_8 -*-

from  conf import *
from threading import Thread
import os
import sys

#print info['host']['dbserver']['a_mix_02']
 

def threaddo(hostip,userid,filename):
	ansibledo = "ansible %s -m shell -a \" su - %s -c ' cd /home/%s/; mkdir  ./bin/%s  ' \"     "   	% (hostip, userid, userid, filename)
	print ansibledo
	
	os.system(ansibledo)

def main():
	for (userid,hostip) in info['host']['dbserver'].items():
		#print "userid: " + userid + ", hostip: " + hostip
		
		userid = Thread(target=threaddo,args=(hostip,userid,filename))
		userid.start()
	
	
if __name__=="__main__": 
        filename = sys.argv[1]
	main()

