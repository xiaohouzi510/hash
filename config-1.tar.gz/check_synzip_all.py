#!/bin/env python
# -*- coding: utf_8 -*-

from  conf import *
from threading import Thread
import os
import sys


#print info['host']['dbserver']['a_mix_02']
 

def threaddo(hostip,userid):
	ansibledo1 = "ansible %s -m shell -a \" ls -l --color=auto  /home/%s/packet/ \"     "   	% (hostip, userid)
	
	print ansibledo1	
	os.system(ansibledo1)
	

def main():
	for (userid,hostip) in info['host']['gameserver'].items():
		#print "userid: " + userid + ", hostip: " + hostip
		
		userid = Thread(target=threaddo,args=(hostip,userid))
		userid.start()
	
	for (userid,hostip) in info['host']['dbserver'].items():
		#print "userid: " + userid + ", hostip: " + hostip
		
		userid = Thread(target=threaddo,args=(hostip,userid))
		userid.start()
	
        for (userid,hostip) in info['host']['combatserver'].items():
                #print "userid: " + userid + ", hostip: " + hostip

                userid = Thread(target=threaddo,args=(hostip,userid))
                userid.start()

        for (userid,hostip) in info['host']['worldserver'].items():
                #print "userid: " + userid + ", hostip: " + hostip

                userid = Thread(target=threaddo,args=(hostip,userid))
                userid.start()

if __name__=="__main__": 
	#zipfile = sys.argv[1]
	#print zipfile
	main()

