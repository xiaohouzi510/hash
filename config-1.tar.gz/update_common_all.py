#!/bin/env python
# -*- coding: utf_8 -*-

from  conf import *
from threading import Thread
import os
import sys


#print info['host']['dbserver']['a_mix_02']
 

def threaddo(hostip,userid):
	import time
	currenttime = time.strftime("%Y%m%d_%H%M%S",time.localtime(time.time()))
	ansibledo1 = "ansible %s -m shell -a \" mkdir -p /data/shellscripts/common/%s/;   cp /home/%s/backup/common_config.lua  /data/shellscripts/common/%s/common_config%s.lua  \"     "   	% (hostip, userid, userid, userid, currenttime)
	ansibledo2 = "ansible %s -m shell -a \" sed -i 's/current_version/--current_version/g' /home/%s/backup/common_config.lua  \"     "   	% (hostip, userid)
	ansibledo3 = "ansible %s -m shell -a \" echo 'current_version               = 7' >> /home/%s/backup/common_config.lua \"  "   	% (hostip, userid)
	ansibledo4 = "ansible %s -m shell -a \" su - %s -c ' cd /home/%s/; bash copy_ini.sh  ' \"     "   	% (hostip, userid, userid)

	print ansibledo1	
	os.system(ansibledo1)
	
	print ansibledo2	
	os.system(ansibledo2)

	print ansibledo3	
	os.system(ansibledo3)
    
	print ansibledo4	
	os.system(ansibledo4)
    
def main():
	for (userid,hostip) in info['host']['gameserver'].items():
		#print "userid: " + userid + ", hostip: " + hostip
		
		userid = Thread(target=threaddo,args=(hostip,userid))
		userid.start()
	
	for (userid,hostip) in info['host']['dbserver'].items():
		#print "userid: " + userid + ", hostip: " + hostip
		
		userid = Thread(target=threaddo,args=(hostip,userid))
		userid.start()
	
        for (userid,hostip) in info['host']['combatserver'].items():
                #print "userid: " + userid + ", hostip: " + hostip

                userid = Thread(target=threaddo,args=(hostip,userid))
                userid.start()

        for (userid,hostip) in info['host']['worldserver'].items():
                #print "userid: " + userid + ", hostip: " + hostip

                userid = Thread(target=threaddo,args=(hostip,userid))
                userid.start()

if __name__=="__main__": 
	#zipfile = sys.argv[1]
	#print zipfile
	main()

