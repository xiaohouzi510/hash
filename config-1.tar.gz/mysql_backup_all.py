#!/bin/env python
# -*- coding: utf_8 -*-

from  conf import *
from threading import Thread
import os


#print info['host']['dbserver']['a_mix_02']
 

def threaddo(hostip):	
	ansibledo = "ansible %s -m shell -a \"  cd /data/shellscripts/; bash mysql_backup_one.sh   \" "   	% (hostip)
	print ansibledo	
	os.system(ansibledo)

def main():
	hostipallrepeat = []
	for (userid,hostip) in info['host']['dbserver'].items():		
		hostipallrepeat.append(hostip)
		#print hostipallrepeat

	hostipall = list(set(hostipallrepeat))
	#print hostipall
	
	for hostip in hostipall:
		#print hostip
		userid = Thread(target=threaddo,args=(hostip,))
		userid.start()
		
if __name__=="__main__": 
	main()

