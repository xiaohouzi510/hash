#!/bin/env python
# -*- coding: utf_8 -*-

from  conf import *
import os
import sys


#print info['host']['dbserver']['a_mix_02']
 
def main():
	servertype = sys.argv[1]
	userid = sys.argv[2]
	#print servertype 
	
	ip = info['host'][servertype][userid]
    
	print "ssh to %s %s %s" % (servertype, userid, ip) 
	
	dossh = "ssh %s" %ip
	#print dossh
	os.system(dossh)
	
if __name__=="__main__": 
	main()

