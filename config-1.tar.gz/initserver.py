#!/bin/env python
# -*- coding: utf_8 -*-

from  conf import *
from threading import Thread
import os
import sys
import time

#print info['host']['dbserver']['a_mix_02']
 

def threaddo(hostip):
	ansibledo1 = "ansible %s -m copy -a \"src=/data/shellscripts/file  dest=/opt/   owner=root group=root mode=0777 \"  "   	% (hostip)
	ansibledo2 = "ansible %s -m shell -a \"mkdir -p /opt/file/{logs,backup} ; cd /opt/file/shell/ ;bash /opt/file/shell/file.sh  \"     "   	% (hostip)
	ansibledo3 = "ansible %s -m shell -a \" rm -rf  /opt/file \"     "   	% (hostip)
	
	print ansibledo1	
	os.system(ansibledo1)

	print ansibledo2	
	os.system(ansibledo2)

	print ansibledo3	
	os.system(ansibledo3)

    
def main():
	gameserverip = info['host']['gameserver'][userid]
	dbserverip   = info['host']['dbserver'][userid]

	th1 = Thread(target=threaddo,args=(gameserverip,))
	th2 = Thread(target=threaddo,args=(dbserverip,))

	th1.start()
	th2.start()

	th1.join()
	th2.join()

	ansibledo4 = "ansible %s -m shell -a \" su - %s -c ' cd /home/%s/; bash do.sh start SCS  ' \"     "   	% (dbserverip, userid, userid)
	print ansibledo4	
	os.system(ansibledo4)
    
	ansibledo5 = "ansible %s -m shell -a \" su - %s -c ' cd /home/%s/; bash do.sh start DBU ' \"     "   	% (dbserverip, userid, userid)
	print ansibledo5	
	os.system(ansibledo5)
    
	time.sleep(5)
    
	ansibledo6 = "ansible %s -m shell -a \" su - %s -c ' cd /home/%s/; bash do.sh kill SCS ' \"     "   	% (dbserverip, userid, userid)
	print ansibledo6	
	os.system(ansibledo6)
    
	ansibledo7 = "ansible %s -m shell -a \" su - %s -c ' cd /home/%s/; bash do.sh kill DBU ' \"     "   	% (dbserverip, userid, userid)
	print ansibledo7	
	os.system(ansibledo7)    
    
	ansibledo8 = "ansible %s -m shell -a \" su - %s -c ' cd /home/%s/; bash do.sh allb ' \"     "   	% (dbserverip, userid, userid)
	print ansibledo8	
	os.system(ansibledo8) 
    
	time.sleep(5)
    
	ansibledo9 = "ansible %s -m shell -a \" su - %s -c ' cd /home/%s/; bash do.sh alla  ' \"     "   	% (gameserverip, userid, userid)
	print ansibledo9	
	os.system(ansibledo9)
	
if __name__=="__main__": 
	userid = sys.argv[1]
	#print info['host']['dbserver'][userid]
    
	main()

