#!/bin/env python
# -*- coding: utf_8 -*-

from  conf import *
from threading import Thread
import os
import sys

#print info['host']['dbserver']['a_mix_02']
 


def threaddo(hostip,userid,fileroute):
	ansibledo = "ansible %s -m shell -a \" ls /home/%s/%s \"     "   	% (hostip, userid, fileroute)
	print ansibledo
	
	os.system(ansibledo)
    
def main():
	for (userid,hostip) in info['host']['gameserver'].items():
		#print "userid: " + userid + ", hostip: " + hostip
		
		userid = Thread(target=threaddo,args=(hostip,userid,fileroute))
		userid.start()

if __name__=="__main__": 
	fileroute = sys.argv[1]
	main()

