#!/bin/env python
# -*- coding: utf_8 -*-

from  conf import *
from threading import Thread
import os
import sys


#print info['host']['dbserver']['a_mix_02']


def main():
	for (userid,hostip) in info['host']['gameserver'].items():
		ping_server = "ansible %s -m ping"  % (hostip)

		print ping_server 
                os.system(ping_server)
	for (userid,hostip) in info['host']['dbserver'].items():
                ping_server = "ansible %s -m ping"  % (hostip)

                print ping_server
                os.system(ping_server)
        for (userid,hostip) in info['host']['combatserver'].items():
                ping_server = "ansible %s -m ping"  % (hostip)

                print ping_server
                os.system(ping_server)
        for (userid,hostip) in info['host']['worldserver'].items():
                ping_server = "ansible %s -m ping"  % (hostip)

                print ping_server
                os.system(ping_server)

if __name__=="__main__": 
	main()

