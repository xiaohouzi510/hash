#!/bin/env python
# -*- coding: utf_8 -*-

from  conf import *
from threading import Thread
import os
import sys


#print info['host']['dbserver']['a_mix_02']


def main():
	for (userid,hostip) in info['host']['gameserver'].items():
		server_ip = "%s %s "  % (hostip, userid)

		print server_ip
	for (userid,hostip) in info['host']['dbserver'].items():
                server_ip = "%s %s "  % (hostip, userid)

                print server_ip 
        for (userid,hostip) in info['host']['combatserver'].items():
                server_ip = "%s %s "  % (hostip, userid)

                print server_ip 
        for (userid,hostip) in info['host']['worldserver'].items():
                server_ip = "%s %s "  % (hostip, userid)

                print server_ip 

if __name__=="__main__": 
	main()

