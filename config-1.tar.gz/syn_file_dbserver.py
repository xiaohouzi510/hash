#!/bin/env python
# -*- coding: utf_8 -*-

from  conf import *
from threading import Thread
import os
import sys

#print info['host']['dbserver']['a_mix_02']
 

def threaddo(hostip,userid,filename,fileroute):
	ansibledo = "ansible %s -m copy -a \"src=/data/shellscripts/opt/%s dest=/home/%s/%s owner=%s group=%s mode='u=rwx,g=rwx,o=rwx' \"  "   	% (hostip, filename, userid, fileroute, userid, userid)
	print ansibledo
	
	os.system(ansibledo)

def main():
	for (userid,hostip) in info['host']['dbserver'].items():
		#print "userid: " + userid + ", hostip: " + hostip
		
		userid = Thread(target=threaddo,args=(hostip,userid,filename,fileroute))
		userid.start()
    
if __name__=="__main__": 
	filename = sys.argv[1]
	fileroute = sys.argv[2]
	main()

